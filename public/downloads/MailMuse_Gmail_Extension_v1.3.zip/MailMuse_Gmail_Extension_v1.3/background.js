chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "MAILMUSE_GENERATE_REPLY") return;

  (async () => {
    try {
      const response = await fetch("https://mailmuse-backend.onrender.com/api/email/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message.payload)
      });

      const raw = await response.text();
      if (!response.ok) throw new Error(`API returned ${response.status}: ${raw || response.statusText}`);

      let data;
      try { data = JSON.parse(raw); } catch { data = raw; }
      sendResponse({ ok: true, data });
    } catch (error) {
      sendResponse({ ok: false, error: error?.message || "Request failed" });
    }
  })();

  return true;
});