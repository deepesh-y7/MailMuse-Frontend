(() => {
  const BUTTON_CLASS = "mailmuse-gmail-button";
  const PANEL_CLASS = "mailmuse-reply-panel";
  const WRAPPER_CLASS = "mailmuse-button-wrapper";

  function cleanText(node) {
    return (node?.innerText || node?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/\n{3,}/g, "\n\n").trim();
  }

  function getComposeEditor(compose) {
    return compose.querySelector('[contenteditable="true"][role="textbox"]') ||
      compose.querySelector('[contenteditable="true"][g_editable="true"]');
  }

  function findComposeContainers() {
    const editors = document.querySelectorAll(
      '[contenteditable="true"][role="textbox"], [contenteditable="true"][g_editable="true"]'
    );
    return [...editors]
      .filter(editor => editor.getClientRects().length > 0)
      .map(editor => editor.closest('[role="dialog"]') || editor.closest('.M9') || editor.closest('.AD'))
      .filter(Boolean);
  }

  function getThreadContext(compose) {
    const main = compose.closest('[role="main"]') || document.querySelector('[role="main"]') || document;
    const bodies = [...main.querySelectorAll(".a3s")]
      .filter(el => el.getClientRects().length > 0)
      .map(cleanText).filter(Boolean);
    return [...new Set(bodies)].slice(-5)
      .join("\n\n--- Previous message ---\n\n").slice(-12000);
  }

  function extractReplyText(data) {
    if (typeof data === "string") return data.trim();
    if (!data || typeof data !== "object") return "";
    for (const key of ["reply", "email", "generatedEmail", "generatedText", "content", "body", "text", "message", "result", "response"]) {
      const value = data[key];
      if (typeof value === "string" && value.trim()) return value.trim();
      if (value && typeof value === "object") {
        const nested = extractReplyText(value);
        if (nested) return nested;
      }
    }
    return "";
  }

  function cleanGeneratedReply(raw) {
    return (raw || "")
      .trim()
      .replace(/^\s*(?:response|generated\s+response|reply)\s*:\s*/i, "")
      .replace(/^\s*subject\s*:\s*[^\n]*(?:\n|$)\s*/i, "")
      .replace(/^```(?:text|plaintext|email)?\s*/i, "")
      .replace(/\s*```\s*$/i, "")
      .replace(/\*\*(.*?)\*\*/g, "$1")
      .trim();
  }

  function setEditorText(editor, text) {
    editor.focus();
    editor.replaceChildren(document.createTextNode(text));
    editor.dispatchEvent(new InputEvent("input", {
      bubbles: true, inputType: "insertText", data: text
    }));
  }

  function makeSelect(className, labelText, options, defaultValue) {
    const wrapper = document.createElement("label");
    wrapper.className = "mailmuse-field";
    const label = document.createElement("span");
    label.textContent = labelText;
    const select = document.createElement("select");
    select.className = className;
    select.tabIndex = 0;
    select.disabled = false;
    select.setAttribute("aria-label", labelText);
    for (const option of options) {
      const item = document.createElement("option");
      item.value = option.value;
      item.textContent = option.label;
      select.appendChild(item);
    }
    select.value = defaultValue;
    wrapper.append(label, select);
    return { wrapper, select };
  }

  function makePanel(compose) {
    const old = compose.querySelector(`.${PANEL_CLASS}`);
    if (old) { old.remove(); return; }

    const panel = document.createElement("div");
    panel.className = PANEL_CLASS;

    const title = document.createElement("div");
    title.className = "mailmuse-panel-title";
    title.textContent = "MailMuse · AI Reply";

    const promptLabel = document.createElement("label");
    promptLabel.className = "mailmuse-label";
    promptLabel.textContent = "Reply instructions (optional)";

    const instructions = document.createElement("textarea");
    instructions.className = "mailmuse-instructions";
    instructions.rows = 2;
    instructions.placeholder = "e.g. Thank them and confirm Friday's meeting";

    const controls = document.createElement("div");
    controls.className = "mailmuse-controls";

    const model = makeSelect("mailmuse-model", "Model", [
      { value: "gemini", label: "Gemini" },
      { value: "openrouter", label: "OpenRouter" }
    ], "gemini");
    const tone = makeSelect("mailmuse-tone", "Tone", [
      { value: "Professional", label: "Professional" },
      { value: "Friendly", label: "Friendly" },
      { value: "Formal", label: "Formal" },
      { value: "Casual", label: "Casual" },
      { value: "Confident", label: "Confident" },
      { value: "Apologetic", label: "Apologetic" }
    ], "Professional");
    const length = makeSelect("mailmuse-length", "Length", [
      { value: "Short", label: "Short" },
      { value: "Medium", label: "Medium" },
      { value: "Long", label: "Long" }
    ], "Medium");
    const language = makeSelect("mailmuse-language", "Language", [
      { value: "English", label: "English" },
      { value: "Hindi", label: "Hindi" },
      { value: "Hinglish", label: "Hinglish" }
    ], "English");

    controls.append(model.wrapper, tone.wrapper, length.wrapper, language.wrapper);

    const actions = document.createElement("div");
    actions.className = "mailmuse-panel-actions";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "mailmuse-cancel";
    cancel.textContent = "Cancel";
    const generate = document.createElement("button");
    generate.type = "button";
    generate.className = "mailmuse-generate";
    generate.textContent = "Generate reply";
    actions.append(cancel, generate);

    const status = document.createElement("div");
    status.className = "mailmuse-status";
    status.setAttribute("aria-live", "polite");

    panel.append(title, promptLabel, instructions, controls, actions, status);

    const editor = getComposeEditor(compose);
    if (editor) editor.insertAdjacentElement("afterend", panel);
    else compose.appendChild(panel);

    for (const select of panel.querySelectorAll("select")) {
      select.addEventListener("pointerdown", event => event.stopPropagation(), true);
      select.addEventListener("mousedown", event => event.stopPropagation(), true);
      select.addEventListener("click", event => event.stopPropagation(), true);
      select.addEventListener("change", event => event.stopPropagation(), true);
    }

    cancel.addEventListener("click", () => panel.remove());

    generate.addEventListener("click", async () => {
      const context = getThreadContext(compose);
      if (!context) {
        status.textContent = "Couldn't find received email text. Open the email thread and try again.";
        return;
      }

      generate.disabled = true;
      status.textContent = "Generating reply…";

      const emailContent =
        "Write only the actual email reply body, ready to paste into Gmail. Do not include a subject line, " +
        "'Response:' label, explanations, markdown, or placeholders in square brackets. Do not invent facts. " +
        "If information is missing, write naturally without placeholders. Use the selected tone, length and language.\n\n" +
        "Received email/thread:\n" + context +
        (instructions.value.trim() ? "\n\nAdditional instructions:\n" + instructions.value.trim() : "");

      const payload = {
        emailContent,
        tone: tone.select.value,
        length: length.select.value,
        language: language.select.value,
        mode: "reply",
        model: model.select.value
      };

      try {
        const result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({ type: "MAILMUSE_GENERATE_REPLY", payload }, response => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            if (!response?.ok) return reject(new Error(response?.error || "Could not generate reply"));
            resolve(response.data);
          });
        });
        const reply = cleanGeneratedReply(extractReplyText(result));
        if (!reply) throw new Error("No reply text found in the API response.");
        const currentEditor = getComposeEditor(compose);
        if (!currentEditor) throw new Error("Gmail reply editor could not be found.");
        setEditorText(currentEditor, reply);
        status.textContent = "Reply inserted. Review it before sending.";
        setTimeout(() => panel.remove(), 2200);
      } catch (error) {
        status.textContent = `Error: ${error.message}`;
      } finally {
        generate.disabled = false;
      }
    });
  }

  function addButton(compose) {
    if (!getComposeEditor(compose) || compose.querySelector(`.${BUTTON_CLASS}`)) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = BUTTON_CLASS;
    button.textContent = "✦ AI Reply";
    button.title = "Draft a reply with MailMuse";
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      makePanel(compose);
    });

    const wrapper = document.createElement("span");
    wrapper.className = WRAPPER_CLASS;
    wrapper.appendChild(button);

    const sendButton = [...compose.querySelectorAll('[role="button"], button')].find(el => {
      const label = [el.getAttribute("data-tooltip"), el.getAttribute("aria-label"), cleanText(el)]
        .filter(Boolean).join(" ").trim();
      return /^send(?:\s|$)/i.test(label);
    });

    if (sendButton?.parentElement) {
      // Gmail's Send button and dropdown are a split control. Place MailMuse
      // after the dropdown too, so it cannot sit between the two Gmail halves.
      const sendGroup = sendButton.closest(".dC") || sendButton;
      const nextControl = sendGroup.nextElementSibling;
      const nextLabel = nextControl
        ? [
            nextControl.getAttribute("data-tooltip"),
            nextControl.getAttribute("aria-label"),
            cleanText(nextControl)
          ].filter(Boolean).join(" ").trim()
        : "";

      const isSendDropdown = !!nextControl && (
        nextControl.matches('[role="button"], button') &&
        (/more send options|send options|schedule send/i.test(nextLabel) ||
          nextControl.querySelector('[aria-label*="send" i], [data-tooltip*="send" i]'))
      );

      const insertionPoint = isSendDropdown ? nextControl : sendGroup;
      insertionPoint.insertAdjacentElement("afterend", wrapper);
    } else {
      getComposeEditor(compose).insertAdjacentElement("afterend", wrapper);
    }
  }

  function scan() {
    for (const compose of findComposeContainers()) addButton(compose);
  }

  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; scan(); });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  scan();
})();
